/*
 * Ultraschall Modul.c
 *
 * The system manages 5 sensors of type HC-SR04 on a continuous basis,
 * collects the resulting distance measurements and 
 * makes it available as I2C slave to a host system. 
 *
 * We have 4 interrupts:
 * - Timer 0 creates an ongoing interrupt at approx. 50 Hz. 
 *   This interrupts is used to trigger the sensors
 * - Pin change interrupt 1 and 2 is reading the echo data from the sensors
 * - I2C interrupt manages the I2C host interface 
 *
 * I2C interface:
 * - register 0 to 4 sends the current data for sensors 0 to 4. Return value is unsigned 16 bit.
 * - register 10: accepts an 8 bit value (0 or 1) which will stop or continue measurements 
 * - register 11: accepts an 8 bit value (0 ... 50) for the delay between 2 triggers in 20 ms units. 
 *   Greater values will give longer breaks between two triggers. Default is 3 (= 60 ms).
 * 
 * Created: 26.01.2021 15:21:23
 * Author : stephan
 */ 

#define F_CPU 8000000L

#include <avr/io.h>
#include <avr/interrupt.h>
#include "TWI_Slave.h"
#include <avr/eeprom.h>
#include <util/delay.h>

// defines -------------------------------------------------------------------------------------------
#define I2C_BASE_ADDRESS		0x5A		// address in case solder jumper is open, otherwise increase by 1
#define TRIGGER_DELAY			10
#define CONVERSION_NUMERATOR	3			// 3/16 -> factor 0.1875
#define CONVESRION_DENOMINATOR	16
#define UPPER_LIMIT				21333		// approximately 4000 mm
#define DELAY_TIME_DEFAULT 		3			// delay time default
#define CYCLE_CNT_MAX			50

// pin assignments
#define HC0_ECHO			2		// Port D
#define HC0_TRIGGER			3
#define HC1_ECHO			4
#define HC1_TRIGGER			5
#define HC2_ECHO			6
#define HC2_TRIGGER			7
#define HC3_ECHO			0		// Port C
#define HC3_TRIGGER			1
#define HC4_ECHO			2
#define HC4_TRIGGER			3
#define ERROR_LED			0		// Port B
#define CTRL_LED			1		
#define I2C_ADDRESS_SWITCH	2		

// commands
#define CMD_GET_MODE		8
#define CMD_GET_CYCLE_TIME	9
#define CMD_SET_STATUS		10
#define CMD_SET_DELAY_TIME	11
#define CMD_SET_MODE		12

// global variables ----------------------------------------------------------------------------------
volatile uint8_t job_flag = 0;
volatile uint16_t median[5] = {0, 0, 0, 0, 0};
volatile uint8_t sens_pnt = 0;
volatile uint8_t echo_flag[5] = {0, 0, 0, 0, 0};  // 0 -> nothing happening, 1 -> trigger executed, 2 -> echo active 
uint8_t system_running = 1;
uint8_t run_mode = 0;
uint8_t error_cnt = 0;
uint8_t cycle_cnt = 0;

// EEPROM data ---------------------------------------------------------------------------------------
#define EE_BASE 0x10
uint8_t EEMEM ee_cycle_cnt = EE_BASE;
uint8_t EEMEM ee_run_mode = EE_BASE + 1;

// Function prototypes -------------------------------------------------------------------------------
void trigger_hc(uint8_t sens);
void init_sens_pnt(void);
void inc_sens_pnt(void); 
void process_input(uint8_t cmd, uint8_t return_buf[], uint8_t *return_buf_len);


// trigger_hc ----------------------------------------------------------------------------------------
void trigger_hc(uint8_t sens) {
	echo_flag[sens] = 1;
	switch (sens) {
		case 0:
			PORTD &= ~(1 << HC0_TRIGGER);
			_delay_us(TRIGGER_DELAY);
			PORTD |= (1 << HC0_TRIGGER);
			break;
		case 1:
			PORTD &= ~(1 << HC1_TRIGGER);
			_delay_us(TRIGGER_DELAY);
			PORTD |= (1 << HC1_TRIGGER);
			break;
		case 2:
			PORTD &= ~(1 << HC2_TRIGGER);
			_delay_us(TRIGGER_DELAY);
			PORTD |= (1 << HC2_TRIGGER);
			break;
		case 3:
			PORTC &= ~(1 << HC3_TRIGGER);
			_delay_us(TRIGGER_DELAY);
			PORTC |= (1 << HC3_TRIGGER);
			break;
		case 4:
			PORTC &= ~(1 << HC4_TRIGGER);
			_delay_us(TRIGGER_DELAY);
			PORTC |= (1 << HC4_TRIGGER);
			break;
		default:					// not allowed
			PORTB |= (1 << 1);
			_delay_ms(250);
			PORTB &= ~(1 << 1);
	}
}

// init_sens_pnt -------------------------------------------------------------------------------------
// initializes the sensor pointer depending on the run mode
// operates on global variables 'sens_pnt' and 'median[]'
void init_sens_pnt(void) {
	sens_pnt = 0;
	
	switch (run_mode) {
		case 0:					// all 5 sensors
			sens_pnt = 0;
			break;
		case 1:					// sensors 0, 1 and 2
			median[3] = median[4] = 0;
			sens_pnt = 0;
			break;
		case 2:					// sensors 3 and 4
			median[0] = median[1] = median[2] = 0;
			sens_pnt = 3;
			break;
		case 3:					// sensors 2 only
			median[0] = median[2] = median[3] = median[4] = 0;
			sens_pnt = 1;
			break;
		default:
			PORTB |= (1 << ERROR_LED);	// not allowed
			error_cnt = 20;
	}
}

// inc_sens_pnt -------------------------------------------------------------------------------------
// increments the sensor pointer depending on the run mode
// operates on global variable 'sens_pnt'
void inc_sens_pnt(void) {
	switch (run_mode) {
		case 0:				// all 5 sensors
			sens_pnt += 1;
			if (sens_pnt > 4) sens_pnt = 0;
			break;
		case 1:				// sensor 0, 1 and 2
			sens_pnt += 1;
			if (sens_pnt > 2) sens_pnt = 0;
			break;
		case 2:				// sensor 3 and 4
			sens_pnt += 1;
			if (sens_pnt > 4) sens_pnt = 3;
			break;
		case 3:				// sensor 2 only
			break;			// no increment required
		default:
			PORTB |= (1 << ERROR_LED);	// not allowed
			error_cnt = 20;
	}
}

// main ----------------------------------------------------------------------------------------------
int main(void) {
	uint8_t return_buf[2], return_buf_len;
	uint8_t cmd_buf[2];
	uint8_t i2c_address;
	
	// set ports to input
	DDRB &= ~(1 << I2C_ADDRESS_SWITCH);					// address switch with pull up
	PORTB |= (1 << I2C_ADDRESS_SWITCH);
	DDRC &= ~((1 << HC3_ECHO) | (1 << HC4_ECHO));		// echo pins, no pull up
	PORTC &= ~((1 << HC3_ECHO) | (1 << HC4_ECHO));
	DDRD &= ~((1 << HC0_ECHO) | (1 << HC1_ECHO) | (1 << HC2_ECHO));
	PORTD &= ~((1 << HC0_ECHO) | (1 << HC1_ECHO) | (1 << HC2_ECHO));
	// set ports to output
	DDRB |= ((1 << CTRL_LED) | (1 << ERROR_LED));		// LEDs
	DDRC |= ((1 << HC3_TRIGGER) | (1 << HC4_TRIGGER));	// trigger pins
	DDRD |= ((1 << HC0_TRIGGER) | (1 << HC1_TRIGGER) | (1 << HC2_TRIGGER));
	// set initial output values
	PORTB &= ~((1 << CTRL_LED) | (1 << ERROR_LED));							// LED is off
	PORTC |= ((1 << HC3_TRIGGER) | (1 << HC4_TRIGGER));						// set to high
	PORTD |= ((1 << HC0_TRIGGER) | (1 << HC1_TRIGGER) |(1 << HC2_TRIGGER));	// set to high
	
	_delay_ms(10);
	
	// setting pin change interrupts
	// PD[2] -> PCINT18, PD[4] -> PCINT20, PD[6] -> PCINT22
	// PC[0] -> PCINT8,  PC[2] -> PCINT10
	PCICR = ((1 << PCIE2) | (1 << PCIE1));     // see page 92
	PCMSK2 = ((1 <<  PCINT18) | (1 << PCINT20) | (1 << PCINT22));
	PCMSK1 = ((1 << PCINT8) | (1 << PCINT10));
	
	// get eeprom data
	cycle_cnt = eeprom_read_byte(&ee_cycle_cnt);
	if (cycle_cnt > CYCLE_CNT_MAX) {
		cycle_cnt = DELAY_TIME_DEFAULT;
		eeprom_write_byte(&ee_cycle_cnt, cycle_cnt);
	}
	run_mode = eeprom_read_byte(&ee_run_mode);
	if (run_mode > 4) {
		run_mode = 0;
		eeprom_write_byte(&ee_run_mode, run_mode);
	}
	init_sens_pnt();

	// setting timer 0, CTC mode, pre-scaler 1024, OCIEA interrupt enabled.
	// this timer runs with approx. 100 Hz, cycle time 10 msec
	TCCR0A = (1 << WGM01);						// WGM01, page 140		
	TCCR0B = ((1 << CS02) | (1 << CS00));		// CS02, CS00
	TIMSK0 = (1 << 1);							// OCIEA
	OCR0A = 79;									// output compare
	
	// setting timer 1 - counts micro seconds
	TCCR1A = 0b00000000;									// operating mode normal
	TCCR1B = ((0 << CS12) | (1 << CS11) | (0 << CS10));     // pre-scaler 8, page 173
	
	// start TWI interface
	if ((PINB & (1 << I2C_ADDRESS_SWITCH)) > 0)	// if solder jumper is open 
		i2c_address = I2C_BASE_ADDRESS;			// set address to BASE_ADDRESS
	else
		i2c_address = I2C_BASE_ADDRESS + 1;		// otherwise increase by 1
	TWI_Slave_Initialise(i2c_address << 1);
	
	// say "hello" via error LED
	for (int i = 0; i < 4; ++i) {
		PINB |= (1 << ERROR_LED);
		_delay_ms(100);
	};
	
	// off we go ...
	sei();
	TWI_Start_Transceiver();
	
    while (1) {
		
		if (job_flag) {
			job_flag = 0;
			if (system_running > 0) {
				trigger_hc(sens_pnt);
				inc_sens_pnt();
			}
			if (error_cnt > 0) {
				--error_cnt;
				if (error_cnt == 0) 
					PORTB &= ~(1 << ERROR_LED);
			}
		}
		
		if (! TWI_Transceiver_Busy() ) {				// check if Transceiver has completed the last operation
			if ( TWI_statusReg.lastTransOK ) {			// check if last operation was a successful
				if ( TWI_statusReg.RxDataInBuf ) {		// check if last operation was a reception
					TWI_Get_Data_From_Transceiver(cmd_buf, 2);	// read message
					process_input(cmd_buf[0], return_buf, &return_buf_len);
					if (return_buf_len > 0) {			// if master requested data, prepare return buffer
						TWI_Start_Transceiver_With_Data(return_buf, return_buf_len);
					}
				}
				if ( ! TWI_Transceiver_Busy()) {
					TWI_Start_Transceiver();
				}
			}
		}
	}
}

//-------------------------------------------------------------------------------------------------------
void process_input(uint8_t cmd, uint8_t return_buf[], uint8_t *return_buf_len) {
	uint16_t result = 0;
	
	switch (cmd & 0b00001111) {
					
		case 0:
			result = median[0];
			*return_buf_len = 2;
			break;			
		
		case 1:
			result = median[3];
			*return_buf_len = 2;
			break;
			
		case 2:
			result = median[1];
			*return_buf_len = 2;
			break;
			
		case 3:
			result = median[4];
			*return_buf_len = 2;
			break;
			
		case 4:
			result = median[2];
			*return_buf_len = 2;
			break;
			
		case CMD_GET_MODE:
			result = run_mode;
			*return_buf_len = 1;
			break;
					
		case CMD_GET_CYCLE_TIME:
			result = cycle_cnt;
			*return_buf_len = 1;
			break;
			
		case CMD_SET_STATUS:
			system_running = cmd >> 4; 
			*return_buf_len = 0;
			break;
			
		case CMD_SET_DELAY_TIME:
			cycle_cnt = cmd >> 4;		
			if (cycle_cnt == 0)	cycle_cnt = DELAY_TIME_DEFAULT;
			if (eeprom_read_byte(&ee_cycle_cnt) != cycle_cnt)
				eeprom_write_byte(&ee_cycle_cnt, cycle_cnt);
			*return_buf_len = 0;
			break;
			
		case CMD_SET_MODE:
			run_mode = cmd >> 4;
			if (run_mode <= 3) {
				if (eeprom_read_byte(&ee_run_mode) != run_mode)
					eeprom_write_byte(&ee_run_mode, run_mode);
			} else {
				run_mode = 0;
			}
			init_sens_pnt();
			*return_buf_len = 0;
			break; 
				
		default:
			PORTB |= (1 << ERROR_LED);
			error_cnt = 20;
			*return_buf_len = 0;
	}
	
	if (*return_buf_len == 2) {
		if (result > UPPER_LIMIT) result = UPPER_LIMIT;
		result = result * CONVERSION_NUMERATOR;
		result = result >> 4;
		return_buf[0] = (uint8_t) (result >> 8);	// high byte
		return_buf[1] = (uint8_t) (result & 0xff);	// low byte
	} else if (*return_buf_len == 1) {
		return_buf[0] = (uint8_t) result; 
	} else {
		return_buf[0] = 0;
		return_buf[1] = 0;
	}
}

/* Interrupt Service Handler -------------------------------------------------------------------*/
// Timer 0
ISR(TIMER0_COMPA_vect) {
	static uint8_t cnt = 0;
	
	cnt += 1;
	if (cnt > cycle_cnt) {
		cnt = 0;
		job_flag = 1;
	}
}

// Pin change interrupts on Port C -------------------------------------------------------------
ISR (PCINT1_vect) {
	static uint16_t start_time_3 = 0, start_time_4 = 0;
	
	if ((echo_flag[3] == 1 ) && (PINC & (1 << HC3_ECHO)) > 0) {  			// echo 3 is active
		start_time_3 = TCNT1;
		echo_flag[3] = 2;
		PORTB |= (1 << CTRL_LED);
	} else if ((echo_flag[3] == 2 ) && (PINC & (1 << HC3_ECHO)) == 0) {		// echo 3 finished
		if (start_time_3 > TCNT1)
			median[3] = 65536 - start_time_3 + TCNT1;
		else
			median[3] = TCNT1 - start_time_3;
		echo_flag[3] = 0;
		PORTB &= ~(1 << CTRL_LED);		
	} else if ((echo_flag[4] == 1 ) && (PINC & (1 << HC4_ECHO)) > 0) {		// echo 4 is active
		start_time_4 = TCNT1;
		echo_flag[4] = 2;
		PORTB |= (1 << CTRL_LED);
	} else if ((echo_flag[4] == 2 ) && (PINC & (1 << HC4_ECHO)) == 0) {		// echo 4 finished
		if (start_time_4 > TCNT1)
			median[4] = 65536 - start_time_4 + TCNT1;
		else
			median[4] = TCNT1 - start_time_4;
		echo_flag[4] = 0;
		PORTB &= ~(1 << CTRL_LED);		
	} else {																// should not happen
		PORTB |= (1 << ERROR_LED);
		error_cnt = 20;
	};
	
}	
		
// Pin change interrupts on Port D -------------------------------------------------------------
ISR(PCINT2_vect) {
	static uint16_t start_time_0 = 0, start_time_1 = 0, start_time_2 = 0;
	
	if ((echo_flag[0] == 1 ) && (PIND & (1 << HC0_ECHO)) > 0) {				// echo 0 is active
		start_time_0 = TCNT1;
		echo_flag[0] = 2;
		PORTB |= (1 << CTRL_LED);
	} else if ((echo_flag[0] == 2 ) && (PIND & (1 << HC0_ECHO)) == 0) {
		if (start_time_0 > TCNT1)
			median[0] = 65536 - start_time_0 + TCNT1;
		else
			median[0] = TCNT1 - start_time_0;
		echo_flag[0] = 0;
		PORTB &= ~(1 << CTRL_LED);		
	} else if ((echo_flag[1] == 1 ) && (PIND & (1 << HC1_ECHO)) > 0) {		// echo 1 is active
		start_time_1 = TCNT1;
		echo_flag[1] = 2;
		PORTB |= (1 << CTRL_LED);
	} else if ((echo_flag[1] == 2 ) && (PIND & (1 << HC1_ECHO)) == 0) {
		if (start_time_1 > TCNT1)
			median[1] = 65536 - start_time_1 + TCNT1;
		else
			median[1] = TCNT1 - start_time_1;
		echo_flag[1] = 0;
		PORTB &= ~(1 << CTRL_LED);		
	} else if ((echo_flag[2] == 1 ) && (PIND & (1 << HC2_ECHO)) > 0) {		// echo 2 is active
		start_time_2 = TCNT1;
		echo_flag[2] = 2;
		PORTB |= (1 << CTRL_LED);
	} else if ((echo_flag[2] == 2 ) && (PIND & (1 << HC2_ECHO)) == 0) {
		if (start_time_2 > TCNT1)
			median[2] = 65536 - start_time_2 + TCNT1;
		else
			median[2] = TCNT1 - start_time_2;
		echo_flag[2] = 0;
		PORTB &= ~(1 << CTRL_LED);		
	} else {																// should not happen
		PORTB |= (1 << ERROR_LED);
		error_cnt = 20;
	}
}
