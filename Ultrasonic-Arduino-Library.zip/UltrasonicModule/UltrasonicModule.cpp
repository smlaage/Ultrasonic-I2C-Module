#include <UltrasonicModule.h>

UltrasonicModule::UltrasonicModule(uint8_t set_i2c_address) {
	i2c_address = set_i2c_address;
}

int UltrasonicModule::read_distance(uint8_t sens) {
	int dist;
	
	Wire.beginTransmission(i2c_address);
	Wire.write(sens);
	Wire.endTransmission(i2c_address);
	Wire.requestFrom(i2c_address, 2, true);
	while (Wire.available() < 1);
	dist = (Wire.read() << 8) | (Wire.read() & 0xff);
	return dist;
}

void UltrasonicModule::set_status(uint8_t running) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_status);
  Wire.write(running);
  Wire.endTransmission(i2c_address);
}

void UltrasonicModule::set_delay_time(uint8_t t) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_delay_time);
  Wire.write(t);
  Wire.endTransmission(i2c_address);
}

void UltrasonicModule::set_run_mode(uint8_t run_mode) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_run_mode);
  Wire.write(run_mode);
  Wire.endTransmission(i2c_address);
}
