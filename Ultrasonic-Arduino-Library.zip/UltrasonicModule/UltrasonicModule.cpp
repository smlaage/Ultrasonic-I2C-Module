#include <UltrasonicModule.h>

int pause = 500;

UltrasonicModule::UltrasonicModule(uint8_t set_i2c_address) {
	i2c_address = set_i2c_address;
}

int UltrasonicModule::get_distance(uint8_t sens) {
	Wire.beginTransmission(i2c_address);
	Wire.write(sens);
	Wire.endTransmission(i2c_address);
	delayMicroseconds(pause);
	Wire.requestFrom(i2c_address, 2, true);
	while (Wire.available() < 1);
	uint16_t dist = (Wire.read() << 8) | (Wire.read() & 0xff);
	return dist;
}

uint8_t UltrasonicModule::get_mode(void) {
	Wire.beginTransmission(i2c_address);
	Wire.write(cmd_get_mode);
	Wire.endTransmission(i2c_address);
	delayMicroseconds(pause);
	Wire.requestFrom(i2c_address, 1, true);
	while (Wire.available() < 1);
	uint8_t mode = Wire.read();
	return mode;
}

uint8_t UltrasonicModule::get_cycle_time(void) {
	Wire.beginTransmission(i2c_address);
	Wire.write(cmd_get_cycle_time);
	Wire.endTransmission(i2c_address);
	delayMicroseconds(pause);
	Wire.requestFrom(i2c_address, 1, true);
	while (Wire.available() < 1);
	uint8_t cycle_time = Wire.read();
	return cycle_time;
}

void UltrasonicModule::set_status(uint8_t running) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_status | (running << 4));
  Wire.endTransmission(i2c_address);
}

void UltrasonicModule::set_cycle_time(uint8_t t) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_cycle_time | (t << 4));
  Wire.endTransmission(i2c_address);
}

void UltrasonicModule::set_mode(uint8_t mode) {
  Wire.beginTransmission(i2c_address);
  Wire.write(cmd_set_mode | (mode << 4));
  Wire.endTransmission(i2c_address);
}
