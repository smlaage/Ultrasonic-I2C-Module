#ifndef __ULTRASONICMODULE__
#define __ULTRASONICMODULE__

#include <Wire.h>
#include <Arduino.h>

class UltrasonicModule {
	
	private:
		uint8_t i2c_address;
		const uint8_t cmd_get_mode = 8;
		const uint8_t cmd_get_cycle_time = 9;
		const uint8_t cmd_set_status = 10;
		const uint8_t cmd_set_cycle_time = 11;
		const uint8_t cmd_set_mode = 12;
		
	public:
		UltrasonicModule(uint8_t set_i2c_address);
		int get_distance(uint8_t sens);
		uint8_t get_mode(void);
		uint8_t get_cycle_time(void);
		void set_status(uint8_t status);
		void set_cycle_time(uint8_t cycle_time);
		void set_mode(uint8_t mode);
};

#endif
	
		