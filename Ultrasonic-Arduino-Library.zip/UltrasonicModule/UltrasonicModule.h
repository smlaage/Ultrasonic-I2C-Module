#ifndef __ULTRASONICMODULE__
#define __ULTRASONICMODULE__

#include <Wire.h>
#include <Arduino.h>

class UltrasonicModule {
	
	private:
		uint8_t i2c_address;
		const uint8_t cmd_set_status = 10;
		const uint8_t cmd_set_delay_time = 11;
		const uint8_t cmd_set_run_mode = 12;
		
	public:
		UltrasonicModule(uint8_t set_i2c_address);
		int read_distance(uint8_t sens);
		void set_status(uint8_t status);
		void set_delay_time(uint8_t delay_time);
		void set_run_mode(uint8_t mode);
};

#endif
	
		